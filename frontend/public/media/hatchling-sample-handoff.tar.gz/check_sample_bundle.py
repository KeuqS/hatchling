# Synthetic local example. No external access.
def sample_names():
    return ("outline.md", "checklist.md")
