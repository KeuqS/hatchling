# Sample bundle

Fictional files for a local interface demonstration.

- check_sample_bundle.py
- bundle-manifest.md
